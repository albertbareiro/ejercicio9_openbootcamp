public class Main {
    public static void main(String[] args) {
        Cliente cliente=new Cliente();
        cliente.edad= 18;
        cliente.nombre ="Santiago";
        cliente.telefono= 98765431;
        cliente.credito=450.52;
        System.out.println("Nombre cliente: " + cliente.nombre);
        System.out.println("tiene: " + cliente.edad + " años.");
        System.out.println("telefono: " + cliente.telefono);
        System.out.println("credito: " + cliente.credito + " USD.");
        Trabajador trabajador=new Trabajador();
        trabajador.edad= 26;
        trabajador.nombre ="Albert";
        trabajador.telefono= 123456789;
        trabajador.salario=980.7;
        System.out.println("Nombre Trabajador: " + trabajador.nombre);
        System.out.println("tiene: " + trabajador.edad + " años.");
        System.out.println("telefono: " + trabajador.telefono);
        System.out.println("credito: " + trabajador.salario + " USD.");
    }
}
class Persona{
    int edad;
    String nombre;
    int telefono;
}
class Cliente extends Persona{
    double credito;
}
class Trabajador extends Persona{
    double salario;
}